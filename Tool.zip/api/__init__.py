"""
API路由包初始化文件
"""

from flask import Blueprint

# 创建API主蓝图
api_bp = Blueprint('api', __name__, url_prefix='/api')

# 导入子蓝图
from . import auth, document, user
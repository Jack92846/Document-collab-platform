# api/document.py
from flask import Blueprint, request, jsonify
from middleware.auth_middleware import permission_required
from services.document_service import DocumentService
from services.version_service import VersionService
from utils.log_utils import SystemLogger

document_bp = Blueprint('document', __name__, url_prefix='/api/documents')
document_service = DocumentService()
version_service = VersionService()
logger = SystemLogger()

@document_bp.route('/', methods=['POST'])
def create_document():
    """创建新文档"""
    try:
        data = request.json
        user_id = request.current_user_id
        
        # 验证必要字段
        required_fields = ['title', 'content']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'缺失必要字段: {field}'}), 400
        
        # 创建文档
        document = document_service.create_document(
            title=data['title'],
            content=data['content'],
            owner_id=user_id,
            category_id=data.get('category_id'),
            tags=data.get('tags', [])
        )
        
        logger.log_operation(
            user_id=user_id,
            operation_type='create',
            target_type='document',
            target_id=document.id,
            details={'title': data['title']}
        )
        
        return jsonify({
            'success': True,
            'document_id': document.id,
            'message': '文档创建成功'
        }), 201
        
    except Exception as e:
        logger.log_error(f"创建文档失败: {str(e)}")
        return jsonify({'error': '创建文档失败', 'details': str(e)}), 500

@document_bp.route('/<int:document_id>', methods=['GET'])
@permission_required('view')
def get_document(document_id):
    """获取文档详情"""
    try:
        user_id = request.current_user_id
        version = request.args.get('version', None)
        
        # 获取文档
        if version:
            # 获取特定版本
            document = version_service.get_version_content(document_id, int(version))
        else:
            # 获取最新版本
            document = document_service.get_document(document_id)
        
        if not document:
            return jsonify({'error': '文档不存在'}), 404
        
        logger.log_operation(
            user_id=user_id,
            operation_type='view',
            target_type='document',
            target_id=document_id,
            details={'version': version}
        )
        
        return jsonify({
            'success': True,
            'document': document.to_dict()
        }), 200
        
    except Exception as e:
        logger.log_error(f"获取文档失败: {str(e)}")
        return jsonify({'error': '获取文档失败'}), 500

@document_bp.route('/<int:document_id>/versions', methods=['GET'])
@permission_required('view')
def get_version_history(document_id):
    """获取版本历史"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        history = version_service.get_version_history(
            document_id=document_id,
            page=page,
            per_page=per_page
        )
        
        return jsonify({
            'success': True,
            'history': history
        }), 200
        
    except Exception as e:
        logger.log_error(f"获取版本历史失败: {str(e)}")
        return jsonify({'error': '获取版本历史失败'}), 500

@document_bp.route('/search', methods=['GET'])
def search_documents():
    """搜索文档"""
    try:
        # 获取查询参数
        keyword = request.args.get('q', '')
        category_id = request.args.get('category_id', type=int)
        owner_id = request.args.get('owner_id', type=int)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # 执行搜索
        results = document_service.search_documents(
            keyword=keyword,
            category_id=category_id,
            owner_id=owner_id,
            page=page,
            per_page=per_page
        )
        
        logger.log_operation(
            user_id=request.current_user_id,
            operation_type='search',
            target_type='document',
            target_id=None,
            details={'keyword': keyword, 'results_count': len(results['documents'])}
        )
        
        return jsonify({
            'success': True,
            'total': results['total'],
            'documents': results['documents']
        }), 200
        
    except Exception as e:
        logger.log_error(f"搜索文档失败: {str(e)}")
        return jsonify({'error': '搜索文档失败'}), 500

@document_bp.route('/batch', methods=['POST'])
def batch_operations():
    """批量操作"""
    try:
        data = request.json
        operation = data.get('operation')
        document_ids = data.get('document_ids', [])
        user_id = request.current_user_id
        
        if not operation or not document_ids:
            return jsonify({'error': '缺少必要参数'}), 400
        
        # 批量操作处理
        if operation == 'archive':
            results = document_service.batch_archive(document_ids, user_id)
        elif operation == 'delete':
            results = document_service.batch_delete(document_ids, user_id)
        elif operation == 'move':
            target_category = data.get('target_category')
            if not target_category:
                return jsonify({'error': '缺少目标分类'}), 400
            results = document_service.batch_move(document_ids, target_category, user_id)
        else:
            return jsonify({'error': '不支持的操作类型'}), 400
        
        logger.log_operation(
            user_id=user_id,
            operation_type=f'batch_{operation}',
            target_type='document',
            target_id=None,
            details={
                'count': len(document_ids),
                'success_count': len([r for r in results if r['status'] == 'success'])
            }
        )
        
        return jsonify({
            'success': True,
            'operation': operation,
            'results': results
        }), 200
        
    except Exception as e:
        logger.log_error(f"批量操作失败: {str(e)}")
        return jsonify({'error': '批量操作失败'}), 500
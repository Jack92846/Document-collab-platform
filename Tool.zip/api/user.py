from flask import Blueprint, request, jsonify
from middleware.auth_middleware import permission_required
from models import User
from utils.log_utils import SystemLogger

user_bp = Blueprint('user', __name__, url_prefix='/users')
logger = SystemLogger()

@user_bp.route('/profile', methods=['GET'])
def get_profile():
    """获取当前用户资料"""
    try:
        user_id = request.current_user_id
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': '用户不存在'}), 404
        
        return jsonify({
            'success': True,
            'profile': user.to_dict()
        }), 200
        
    except Exception as e:
        logger.log_error(f"获取用户资料失败: {str(e)}")
        return jsonify({'error': '获取资料失败'}), 500

@user_bp.route('/profile', methods=['PUT'])
def update_profile():
    """更新用户资料"""
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': '用户不存在'}), 404
        
        # 更新允许修改的字段
        if 'real_name' in data:
            user.real_name = data['real_name']
        
        from app import db
        db.session.commit()
        
        logger.log_operation(
            user_id=user_id,
            operation_type='update_profile',
            target_type='user',
            target_id=user_id
        )
        
        return jsonify({
            'success': True,
            'message': '资料更新成功'
        }), 200
        
    except Exception as e:
        logger.log_error(f"更新用户资料失败: {str(e)}")
        return jsonify({'error': '更新失败'}), 500
"""
用户认证与授权API
包含登录、注册、令牌刷新等功能
"""

from flask import Blueprint, request, jsonify, current_app
from werkzeug.security import check_password_hash
import jwt
import datetime
from models.user import User
from utils.auth_utils import generate_token, validate_token
from utils.log_utils import SystemLogger

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')
logger = SystemLogger()

@auth_bp.route('/register', methods=['POST'])
def register():
    """
    用户注册
    POST /api/auth/register
    {
        "username": "user123",
        "email": "user@example.com",
        "password": "123456",
        "real_name": "张三"
    }
    """
    try:
        data = request.get_json()
        
        # 验证必要字段
        required_fields = ['username', 'email', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'缺失字段: {field}'}), 400
        
        # 检查用户是否存在
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': '用户名已存在'}), 409
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': '邮箱已存在'}), 409
        
        # 创建用户
        user = User(
            username=data['username'],
            email=data['email'],
            real_name=data.get('real_name')
        )
        user.set_password(data['password'])
        
        from app import db
        db.session.add(user)
        db.session.commit()
        
        logger.log_operation(
            user_id=user.id,
            operation_type='register',
            target_type='user',
            target_id=user.id
        )
        
        return jsonify({
            'success': True,
            'message': '注册成功',
            'user_id': user.id
        }), 201
        
    except Exception as e:
        logger.log_error(f"注册失败: {str(e)}")
        return jsonify({'error': '注册失败'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """
    用户登录
    POST /api/auth/login
    {
        "username": "user123",
        "password": "secure_password"
    }
    """
    try:
        data = request.get_json()
        
        # 验证必要字段
        if not data.get('username') or not data.get('password'):
            return jsonify({'error': '用户名和密码不能为空'}), 400
        
        # 查找用户
        user = User.query.filter_by(username=data['username']).first()
        if not user or not user.check_password(data['password']):
            return jsonify({'error': '用户名或密码错误'}), 401
        
        # 检查用户状态
        if not user.is_active:
            return jsonify({'error': '账户已被禁用'}), 403
        
        # 生成令牌
        access_token = generate_token(user.id, user.role_id)
        refresh_token = generate_token(user.id, user.role_id, refresh=True)
        
        # 更新最后登录时间
        user.update_last_login()
        from app import db
        db.session.commit()
        
        logger.log_operation(
            user_id=user.id,
            operation_type='login',
            target_type='user',
            target_id=user.id
        )
        
        return jsonify({
            'success': True,
            'access_token': access_token,
            'refresh_token': refresh_token,
            'expires_in': current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES', 3600),
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'real_name': user.real_name,
                'role': user.role.name if user.role else None
            }
        }), 200
        
    except Exception as e:
        logger.log_error(f"登录失败: {str(e)}")
        return jsonify({'error': '登录失败'}), 500

@auth_bp.route('/refresh', methods=['POST'])
def refresh_token():
    """
    刷新访问令牌
    POST /api/auth/refresh
    {
        "refresh_token": "your_refresh_token"
    }
    """
    try:
        data = request.get_json()
        refresh_token = data.get('refresh_token')
        
        if not refresh_token:
            return jsonify({'error': '刷新令牌不能为空'}), 400
        
        # 验证刷新令牌
        payload = validate_token(refresh_token, is_refresh=True)
        if not payload:
            return jsonify({'error': '无效的刷新令牌'}), 401
        
        user_id = payload.get('user_id')
        user = User.query.get(user_id)
        
        if not user or not user.is_active:
            return jsonify({'error': '用户不存在或已被禁用'}), 401
        
        # 生成新的访问令牌
        new_access_token = generate_token(user.id, user.role_id)
        
        return jsonify({
            'success': True,
            'access_token': new_access_token,
            'expires_in': current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES', 3600)
        }), 200
        
    except Exception as e:
        logger.log_error(f"令牌刷新失败: {str(e)}")
        return jsonify({'error': '令牌刷新失败'}), 500
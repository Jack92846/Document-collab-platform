"""
数据库模型包初始化文件
"""

from app import db
from .user import User, Role
from .document import Document, DocumentVersion, Category, Tag
from .permission import Permission, DocumentPermission

__all__ = [
    'User', 'Role',
    'Document', 'DocumentVersion', 'Category', 'Tag',
    'Permission', 'DocumentPermission'
]
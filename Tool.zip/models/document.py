from app import db
from datetime import datetime

class Category(db.Model):
    """文档分类"""
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.String(200))
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 自关联
    parent = db.relationship('Category', remote_side=[id], backref='children')
    documents = db.relationship('Document', backref='category', lazy='dynamic')
    
    def __repr__(self):
        return f'<Category {self.name}>'


class Document(db.Model):
    """文档模型"""
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    summary = db.Column(db.String(500))
    
    # 外键
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    
    # 状态
    status = db.Column(db.Enum('draft', 'published', 'archived'), default='draft')
    is_deleted = db.Column(db.Boolean, default=False)
    
    # 统计
    view_count = db.Column(db.Integer, default=0)
    download_count = db.Column(db.Integer, default=0)
    
    # 版本
    current_version = db.Column(db.Integer, default=1)
    
    # 时间
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Document {self.title}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'owner': self.owner.username if self.owner else None,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'view_count': self.view_count
        }
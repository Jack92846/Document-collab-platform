from app import db
from datetime import datetime

class Permission(db.Model):
    """权限模型"""
    __tablename__ = 'permissions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'), nullable=False)
    
    # 权限类型：view, edit, delete, admin
    permission_type = db.Column(db.String(20), nullable=False)
    
    granted_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    granted_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)
    
    # 关系
    document = db.relationship('Document', backref='permissions')
    grantor = db.relationship('User', foreign_keys=[granted_by])
    
    def __repr__(self):
        return f'<Permission {self.user_id}-{self.document_id}-{self.permission_type}>'
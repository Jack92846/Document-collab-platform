"""
用户数据模型
包含用户、角色等实体定义
"""

from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

class Role(db.Model):
    """角色模型 - RBAC核心"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False, comment='角色名称')
    description = db.Column(db.String(200), comment='角色描述')
    level = db.Column(db.Integer, nullable=False, default=3, comment='角色等级，数字越小权限越高')
    is_default = db.Column(db.Boolean, default=False, comment='是否为默认角色')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    users = db.relationship('User', backref='role', lazy=True)
    
    def __repr__(self):
        return f'<Role {self.name}>'
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'level': self.level,
            'is_default': self.is_default
        }


class User(db.Model):
    """用户模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False, index=True, comment='用户名')
    email = db.Column(db.String(100), unique=True, nullable=False, index=True, comment='邮箱')
    password_hash = db.Column(db.String(255), nullable=False, comment='密码哈希')
    real_name = db.Column(db.String(50), comment='真实姓名')
    avatar_url = db.Column(db.String(255), comment='头像URL')
    
    # 外键
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=False, default=3)
    
    # 状态字段
    is_active = db.Column(db.Boolean, default=True, comment='是否激活')
    is_verified = db.Column(db.Boolean, default=False, comment='邮箱是否验证')
    
    # 时间字段
    last_login_at = db.Column(db.DateTime, comment='最后登录时间')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    documents = db.relationship('Document', backref='owner', lazy='dynamic', foreign_keys='Document.owner_id')
    permissions = db.relationship('Permission', backref='user', lazy='dynamic')
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    @property
    def password(self):
        """密码属性（只读）"""
        raise AttributeError('password is not a readable attribute')
    
    @password.setter
    def password(self, password):
        """设置密码（自动哈希）"""
        self.password_hash = generate_password_hash(password)
    
    def set_password(self, password):
        """设置密码"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """验证密码"""
        return check_password_hash(self.password_hash, password)
    
    def update_last_login(self):
        """更新最后登录时间"""
        self.last_login_at = datetime.utcnow()
    
    def to_dict(self, include_sensitive=False):
        """转换为字典"""
        data = {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'real_name': self.real_name,
            'avatar_url': self.avatar_url,
            'role': self.role.to_dict() if self.role else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login_at': self.last_login_at.isoformat() if self.last_login_at else None
        }
        
        if include_sensitive:
            data['is_verified'] = self.is_verified
        
        return data
    
    def has_permission(self, permission_code):
        """
        检查用户是否有特定权限
        
        Args:
            permission_code: 权限代码
        
        Returns:
            bool: 是否拥有权限
        """
        # 基于角色的权限检查
        # 实际项目中可能需要更复杂的权限模型
        return True
"""
应用配置文件
根据环境变量加载不同配置
"""

import os
from datetime import timedelta
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class Config:
    """基础配置类"""
    
    # 基础配置
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    DEBUG = False
    
    # 数据库配置
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = os.environ.get('DB_PORT', '3306')
    DB_USER = os.environ.get('DB_USER', 'document_user')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', 'your_password_here')  #(126912)
    DB_NAME = os.environ.get('DB_NAME', 'document_management')
    
    # SQLAlchemy配置
    SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_POOL_SIZE = int(os.environ.get('SQLALCHEMY_POOL_SIZE', 10))
    SQLALCHEMY_MAX_OVERFLOW = int(os.environ.get('SQLALCHEMY_MAX_OVERFLOW', 20))
    SQLALCHEMY_POOL_RECYCLE = int(os.environ.get('SQLALCHEMY_POOL_RECYCLE', 3600))
    
    # 文件上传配置
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/uploads')
    MAX_CONTENT_LENGTH = int(os.environ.get('MAX_CONTENT_LENGTH', 50 * 1024 * 1024))  # 50MB
    ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'jpg', 'png'}
    
    # 会话配置
    SESSION_COOKIE_NAME = 'document_session'
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # 缓存配置
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 300
    
    # 性能配置
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 3600,
    }


class DevelopmentConfig(Config):
    """开发环境配置"""
    DEBUG = True
    SQLALCHEMY_ECHO = True  # 输出SQL日志
    EXPLAIN_TEMPLATE_LOADING = False
    
    # 开发数据库
    DB_HOST = os.environ.get('DEV_DB_HOST', 'localhost')
    DB_NAME = os.environ.get('DEV_DB_NAME', 'document_management_dev')


class TestingConfig(Config):
    """测试环境配置"""
    TESTING = True
    DEBUG = True
    DB_NAME = os.environ.get('TEST_DB_NAME', 'document_management_test')
    SQLALCHEMY_DATABASE_URI = f"sqlite:///:memory:"


class ProductionConfig(Config):
    """生产环境配置"""
    DEBUG = False
    
    # 生产环境密钥（必须通过环境变量设置）
    SECRET_KEY = os.environ.get('PRODUCTION_SECRET_KEY')
    if not SECRET_KEY:
        raise ValueError("生产环境必须设置 SECRET_KEY 环境变量")
    
    # 生产数据库
    DB_HOST = os.environ.get('PRODUCTION_DB_HOST')
    DB_PASSWORD = os.environ.get('PRODUCTION_DB_PASSWORD')
    
    # 生产优化
    SQLALCHEMY_POOL_SIZE = 20
    SQLALCHEMY_MAX_OVERFLOW = 30
    
    # 安全配置
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'


# 配置字典
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}

def get_config():
    """
    根据环境变量获取配置
    
    Returns:
        Config: 配置类实例
    """
    env = os.environ.get('FLASK_ENV', 'development').lower()
    return config.get(env, config['default'])
# middleware/auth_middleware.py
from functools import wraps
from flask import request, jsonify
from utils.auth_utils import RBACValidator

def permission_required(permission_type):
    """
    权限检查装饰器
    
    Args:
        permission_type: 需要的权限类型
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # 获取当前用户
            user_id = getattr(request, 'current_user_id', None)
            if not user_id:
                return jsonify({'error': '未认证'}), 401
            
            # 获取文档ID（从URL参数或请求体）
            document_id = kwargs.get('document_id') or \
                         request.args.get('document_id') or \
                         request.json.get('document_id', None)
            
            if not document_id:
                return jsonify({'error': '文档ID缺失'}), 400
            
            # 权限检查
            validator = RBACValidator(current_app)
            if not validator.check_document_permission(user_id, document_id, permission_type):
                return jsonify({'error': '权限不足'}), 403
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator
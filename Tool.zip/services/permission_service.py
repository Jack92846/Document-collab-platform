from app import db
from models import Permission, Document, User
from utils.log_utils import SystemLogger
from datetime import datetime

class PermissionService:
    """权限管理服务"""
    
    def __init__(self):
        self.logger = SystemLogger()
    
    def grant_permission(self, user_id, document_id, permission_type, granted_by, expires_at=None):
        """
        授予文档权限
        
        Args:
            user_id: 用户ID
            document_id: 文档ID
            permission_type: 权限类型
            granted_by: 授予者ID
            expires_at: 过期时间
        
        Returns:
            Permission: 权限对象
        """
        try:
            # 检查文档是否存在
            document = Document.query.get(document_id)
            if not document:
                raise ValueError(f"文档 {document_id} 不存在")
            
            # 检查用户是否存在
            user = User.query.get(user_id)
            if not user:
                raise ValueError(f"用户 {user_id} 不存在")
            
            # 创建或更新权限
            permission = Permission.query.filter_by(
                user_id=user_id,
                document_id=document_id,
                permission_type=permission_type
            ).first()
            
            if permission:
                # 更新现有权限
                permission.expires_at = expires_at
                permission.granted_by = granted_by
                permission.granted_at = datetime.utcnow()
            else:
                # 创建新权限
                permission = Permission(
                    user_id=user_id,
                    document_id=document_id,
                    permission_type=permission_type,
                    granted_by=granted_by,
                    expires_at=expires_at
                )
                db.session.add(permission)
            
            db.session.commit()
            
            self.logger.log_operation(
                user_id=granted_by,
                operation_type='grant_permission',
                target_type='permission',
                target_id=permission.id
            )
            
            return permission
            
        except Exception as e:
            db.session.rollback()
            self.logger.log_error(f"授予权限失败: {str(e)}")
            raise
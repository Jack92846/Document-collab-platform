"""
文件处理服务模块
负责文件上传、下载、转换、压缩、批量处理等核心文件操作
"""

import os
import hashlib
import uuid
import zipfile
import tempfile
import mimetypes
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, BinaryIO, Union
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage
from PIL import Image
import magic

from app import db
from config import Config
from models.document import Document, DocumentVersion
from models.user import User
from utils.log_utils import SystemLogger
from utils.file_utils import FileProcessor


class FileService:
    """文件处理服务类"""
    
    def __init__(self):
        self.logger = SystemLogger()
        self.file_processor = FileProcessor(
            upload_folder=Config.UPLOAD_FOLDER,
            max_size=Config.MAX_CONTENT_LENGTH
        )
        
        # 文件类型映射
        self.mime_type_map = {
            'text/plain': 'txt',
            'application/pdf': 'pdf',
            'application/msword': 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
            'application/vnd.ms-excel': 'xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
            'application/vnd.ms-powerpoint': 'ppt',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
            'image/jpeg': 'jpg',
            'image/png': 'png',
            'image/gif': 'gif',
            'image/webp': 'webp',
            'application/zip': 'zip',
            'application/x-rar-compressed': 'rar',
            'application/x-7z-compressed': '7z'
        }
    
    def upload_file(self, file: FileStorage, user_id: int, 
                   category: str = 'documents', metadata: Dict = None) -> Dict:
        """
        上传单个文件
        
        Args:
            file: 文件对象
            user_id: 用户ID
            category: 文件分类 ('documents', 'images', 'attachments')
            metadata: 文件元数据
        
        Returns:
            Dict: 上传结果
        """
        try:
            # 1. 验证文件
            validation_result = self.file_processor.validate_file(
                file.stream, file.filename
            )
            
            if not validation_result['valid']:
                return {
                    'success': False,
                    'error': validation_result['error']
                }
            
            # 2. 生成唯一文件名
            original_filename = file.filename
            unique_filename = self.file_processor.generate_unique_filename(original_filename)
            
            # 3. 创建保存路径
            save_path = self._create_save_path(category, unique_filename)
            
            # 4. 保存文件
            file.save(str(save_path))
            
            # 5. 计算文件哈希
            file_hash = self._calculate_file_hash(save_path)
            
            # 6. 提取文件信息
            file_info = self._extract_file_info(save_path, original_filename)
            
            # 7. 创建数据库记录（可选）
            file_record = self._create_file_record(
                original_filename=original_filename,
                saved_filename=unique_filename,
                file_hash=file_hash,
                user_id=user_id,
                category=category,
                file_info=file_info,
                metadata=metadata or {}
            )
            
            # 8. 如果是图片，生成缩略图
            if file_info['file_type'] == '图片':
                thumbnail_path = self._generate_thumbnail(save_path, unique_filename)
                file_info['thumbnail'] = str(thumbnail_path.relative_to(Config.UPLOAD_FOLDER))
            
            # 9. 记录日志
            self.logger.log_operation(
                user_id=user_id,
                operation_type='upload_file',
                target_type='file',
                target_id=file_record.id if file_record else None,
                details={
                    'filename': original_filename,
                    'saved_as': unique_filename,
                    'size': file_info['size'],
                    'file_type': file_info['file_type']
                }
            )
            
            return {
                'success': True,
                'file_id': file_record.id if file_record else None,
                'original_name': original_filename,
                'saved_name': unique_filename,
                'file_path': str(save_path.relative_to(Config.UPLOAD_FOLDER)),
                'file_hash': file_hash,
                'file_info': file_info,
                'download_url': f'/api/files/download/{unique_filename}',
                'preview_url': f'/api/files/preview/{unique_filename}' if file_info.get('previewable') else None
            }
            
        except Exception as e:
            self.logger.log_error(f"文件上传失败: {str(e)}", {'filename': file.filename})
            return {
                'success': False,
                'error': f'文件上传失败: {str(e)}'
            }
    
    def upload_multiple_files(self, files: List[FileStorage], user_id: int, 
                            category: str = 'documents') -> Dict:
        """
        批量上传文件
        
        Args:
            files: 文件对象列表
            user_id: 用户ID
            category: 文件分类
        
        Returns:
            Dict: 批量上传结果
        """
        results = {
            'success': [],
            'failed': [],
            'total': len(files),
            'success_count': 0,
            'failed_count': 0
        }
        
        for file in files:
            result = self.upload_file(file, user_id, category)
            
            if result['success']:
                results['success'].append(result)
                results['success_count'] += 1
            else:
                results['failed'].append({
                    'filename': file.filename,
                    'error': result.get('error', '未知错误')
                })
                results['failed_count'] += 1
        
        # 记录批量操作日志
        self.logger.log_operation(
            user_id=user_id,
            operation_type='batch_upload',
            target_type='file',
            target_id=None,
            details={
                'total': len(files),
                'success': results['success_count'],
                'failed': results['failed_count']
            }
        )
        
        return results
    
    def download_file(self, filename: str, user_id: int, 
                     as_attachment: bool = True) -> Tuple[Optional[Path], Dict]:
        """
        下载文件
        
        Args:
            filename: 文件名
            user_id: 用户ID
            as_attachment: 是否作为附件下载
        
        Returns:
            Tuple[Optional[Path], Dict]: (文件路径, 文件信息)
        """
        try:
            # 1. 查找文件
            file_path = self._find_file_by_name(filename)
            if not file_path or not file_path.exists():
                return None, {'error': '文件不存在'}
            
            # 2. 获取文件信息
            file_info = self._get_file_info(file_path)
            
            # 3. 检查下载权限（这里可以根据业务需求实现）
            # if not self._check_download_permission(filename, user_id):
            #     return None, {'error': '没有下载权限'}
            
            # 4. 更新下载统计
            self._update_download_stats(filename, user_id)
            
            # 5. 记录下载日志
            self.logger.log_operation(
                user_id=user_id,
                operation_type='download_file',
                target_type='file',
                target_id=None,
                details={
                    'filename': filename,
                    'size': file_info['size'],
                    'as_attachment': as_attachment
                }
            )
            
            return file_path, file_info
            
        except Exception as e:
            self.logger.log_error(f"文件下载失败: {str(e)}", {'filename': filename})
            return None, {'error': f'文件下载失败: {str(e)}'}
    
    def download_multiple_as_zip(self, filenames: List[str], user_id: int, 
                               zip_name: str = None) -> Tuple[Optional[Path], Dict]:
        """
        批量下载文件为ZIP压缩包
        
        Args:
            filenames: 文件名列表
            user_id: 用户ID
            zip_name: 压缩包名称
        
        Returns:
            Tuple[Optional[Path], Dict]: (ZIP文件路径, 压缩信息)
        """
        temp_dir = None
        try:
            # 1. 创建临时目录
            temp_dir = Path(tempfile.mkdtemp())
            
            # 2. 准备压缩包名称
            if not zip_name:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                zip_name = f'documents_{timestamp}.zip'
            
            zip_path = temp_dir / zip_name
            
            # 3. 创建ZIP文件
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for filename in filenames:
                    file_path = self._find_file_by_name(filename)
                    if file_path and file_path.exists():
                        # 在ZIP中使用原始文件名
                        original_name = self._get_original_filename(filename)
                        zipf.write(file_path, arcname=original_name or filename)
            
            # 4. 获取压缩包信息
            zip_info = {
                'filename': zip_name,
                'size': zip_path.stat().st_size,
                'file_count': len(filenames),
                'compressed_size': zip_path.stat().st_size,
                'created_at': datetime.now().isoformat()
            }
            
            # 5. 记录批量下载日志
            self.logger.log_operation(
                user_id=user_id,
                operation_type='batch_download_zip',
                target_type='file',
                target_id=None,
                details={
                    'file_count': len(filenames),
                    'zip_name': zip_name,
                    'zip_size': zip_info['size']
                }
            )
            
            return zip_path, zip_info
            
        except Exception as e:
            self.logger.log_error(f"创建ZIP压缩包失败: {str(e)}", {'filenames': filenames})
            return None, {'error': f'创建压缩包失败: {str(e)}'}
            
        finally:
            # 注意：临时文件需要在调用方处理完后手动删除
            pass
    
    def convert_file_format(self, filename: str, target_format: str, 
                          user_id: int) -> Tuple[Optional[Path], Dict]:
        """
        转换文件格式
        
        Args:
            filename: 源文件名
            target_format: 目标格式
            user_id: 用户ID
        
        Returns:
            Tuple[Optional[Path], Dict]: (转换后的文件路径, 转换信息)
        """
        try:
            # 1. 查找源文件
            source_path = self._find_file_by_name(filename)
            if not source_path or not source_path.exists():
                return None, {'error': '源文件不存在'}
            
            # 2. 检查是否支持转换
            source_info = self._get_file_info(source_path)
            source_ext = source_path.suffix.lower()[1:]  # 去掉点号
            
            if not self._is_conversion_supported(source_ext, target_format):
                return None, {'error': f'不支持从 {source_ext} 转换为 {target_format}'}
            
            # 3. 执行转换
            converted_path = self._perform_conversion(
                source_path, source_ext, target_format, user_id
            )
            
            if not converted_path:
                return None, {'error': '文件转换失败'}
            
            # 4. 获取转换后文件信息
            converted_info = self._get_file_info(converted_path)
            
            # 5. 记录转换日志
            self.logger.log_operation(
                user_id=user_id,
                operation_type='convert_file',
                target_type='file',
                target_id=None,
                details={
                    'source': filename,
                    'source_format': source_ext,
                    'target_format': target_format,
                    'target_file': converted_path.name
                }
            )
            
            return converted_path, converted_info
            
        except Exception as e:
            self.logger.log_error(f"文件格式转换失败: {str(e)}", {
                'filename': filename,
                'target_format': target_format
            })
            return None, {'error': f'格式转换失败: {str(e)}'}
    
    def compress_images(self, filenames: List[str], user_id: int, 
                       quality: int = 85) -> Dict:
        """
        压缩图片文件
        
        Args:
            filenames: 图片文件名列表
            user_id: 用户ID
            quality: 压缩质量 (1-100)
        
        Returns:
            Dict: 压缩结果
        """
        results = []
        
        for filename in filenames:
            try:
                file_path = self._find_file_by_name(filename)
                if not file_path or not file_path.exists():
                    results.append({
                        'filename': filename,
                        'success': False,
                        'error': '文件不存在'
                    })
                    continue
                
                # 检查是否为图片
                file_info = self._get_file_info(file_path)
                if file_info['file_type'] != '图片':
                    results.append({
                        'filename': filename,
                        'success': False,
                        'error': '非图片文件'
                    })
                    continue
                
                # 压缩图片
                compressed_path = self._compress_image_file(
                    file_path, quality, user_id
                )
                
                if compressed_path:
                    compressed_info = self._get_file_info(compressed_path)
                    original_size = file_info['size']
                    compressed_size = compressed_info['size']
                    
                    results.append({
                        'filename': filename,
                        'success': True,
                        'original_size': original_size,
                        'compressed_size': compressed_size,
                        'saved_bytes': original_size - compressed_size,
                        'compression_ratio': f"{((original_size - compressed_size) / original_size * 100):.1f}%",
                        'compressed_file': compressed_path.name
                    })
                else:
                    results.append({
                        'filename': filename,
                        'success': False,
                        'error': '图片压缩失败'
                    })
                    
            except Exception as e:
                results.append({
                    'filename': filename,
                    'success': False,
                    'error': str(e)
                })
        
        # 记录批量压缩日志
        success_count = len([r for r in results if r['success']])
        self.logger.log_operation(
            user_id=user_id,
            operation_type='compress_images',
            target_type='file',
            target_id=None,
            details={
                'total': len(filenames),
                'success': success_count,
                'failed': len(filenames) - success_count,
                'quality': quality
            }
        )
        
        return {
            'results': results,
            'summary': {
                'total': len(filenames),
                'success': success_count,
                'failed': len(filenames) - success_count
            }
        }
    
    def delete_file(self, filename: str, user_id: int, 
                   soft_delete: bool = True) -> Dict:
        """
        删除文件
        
        Args:
            filename: 文件名
            user_id: 用户ID
            soft_delete: 是否软删除（移动到回收站）
        
        Returns:
            Dict: 删除结果
        """
        try:
            # 1. 查找文件
            file_path = self._find_file_by_name(filename)
            if not file_path or not file_path.exists():
                return {'success': False, 'error': '文件不存在'}
            
            # 2. 检查删除权限
            # if not self._check_delete_permission(filename, user_id):
            #     return {'success': False, 'error': '没有删除权限'}
            
            # 3. 执行删除
            if soft_delete:
                # 软删除：移动到回收站目录
                recycle_bin = Config.UPLOAD_FOLDER / 'recycle_bin'
                recycle_bin.mkdir(exist_ok=True)
                
                # 添加删除时间戳
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                new_name = f"{timestamp}_{file_path.name}"
                recycle_path = recycle_bin / new_name
                
                # 移动文件
                shutil.move(str(file_path), str(recycle_path))
                
                # 更新数据库记录（如果存在）
                self._update_file_record(filename, {'is_deleted': True})
                
                message = '文件已移动到回收站'
            else:
                # 硬删除：永久删除
                file_path.unlink()
                
                # 删除缩略图（如果存在）
                thumbnail_path = self._get_thumbnail_path(filename)
                if thumbnail_path.exists():
                    thumbnail_path.unlink()
                
                # 删除数据库记录
                self._delete_file_record(filename)
                
                message = '文件已永久删除'
            
            # 4. 记录删除日志
            self.logger.log_operation(
                user_id=user_id,
                operation_type='delete_file',
                target_type='file',
                target_id=None,
                details={
                    'filename': filename,
                    'soft_delete': soft_delete,
                    'permanent': not soft_delete
                }
            )
            
            return {
                'success': True,
                'message': message,
                'filename': filename,
                'deleted_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.log_error(f"文件删除失败: {str(e)}", {'filename': filename})
            return {'success': False, 'error': f'文件删除失败: {str(e)}'}
    
    # ==================== 私有辅助方法 ====================
    
    def _create_save_path(self, category: str, filename: str) -> Path:
        """创建文件保存路径"""
        # 按日期组织目录
        date_str = datetime.now().strftime('%Y/%m/%d')
        save_dir = Config.UPLOAD_FOLDER / category / date_str
        
        # 创建目录（如果不存在）
        save_dir.mkdir(parents=True, exist_ok=True)
        
        return save_dir / filename
    
    def _calculate_file_hash(self, file_path: Path, algorithm: str = 'sha256') -> str:
        """计算文件哈希值"""
        hash_func = hashlib.new(algorithm)
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hash_func.update(chunk)
        
        return hash_func.hexdigest()
    
    def _extract_file_info(self, file_path: Path, original_name: str) -> Dict:
        """提取文件信息"""
        stat = file_path.stat()
        
        # 获取MIME类型
        mime = magic.from_file(str(file_path), mime=True)
        
        # 获取文件类型分类
        file_type = '其他'
        for type_name, extensions in self.file_processor.allowed_extensions.items():
            if file_path.suffix.lower() in extensions:
                file_type = type_name
                break
        
        # 检查是否可预览
        previewable = mime.startswith(('image/', 'text/', 'application/pdf'))
        
        return {
            'original_name': original_name,
            'saved_name': file_path.name,
            'size': stat.st_size,
            'size_human': self._humanize_size(stat.st_size),
            'mime_type': mime,
            'extension': file_path.suffix.lower()[1:],  # 去掉点号
            'file_type': file_type,
            'created_time': datetime.fromtimestamp(stat.st_ctime).isoformat(),
            'modified_time': datetime.fromtimestamp(stat.st_mtime).isoformat(),
            'previewable': previewable
        }
    
    def _create_file_record(self, original_filename: str, saved_filename: str,
                          file_hash: str, user_id: int, category: str,
                          file_info: Dict, metadata: Dict) -> Optional[object]:
        """
        创建文件数据库记录
        
        注意：这里的实现需要根据实际的数据模型进行调整
        """
        try:
            # 示例实现，需要根据您的模型调整
            from models.file import FileRecord  # 假设有这个模型
            
            file_record = FileRecord(
                original_name=original_filename,
                saved_name=saved_filename,
                file_hash=file_hash,
                user_id=user_id,
                category=category,
                mime_type=file_info['mime_type'],
                size=file_info['size'],
                metadata=metadata
            )
            
            db.session.add(file_record)
            db.session.commit()
            
            return file_record
            
        except Exception as e:
            self.logger.log_error(f"创建文件记录失败: {str(e)}", {
                'filename': original_filename
            })
            db.session.rollback()
            return None
    
    def _generate_thumbnail(self, image_path: Path, filename: str, 
                          size: Tuple[int, int] = (200, 200)) -> Path:
        """生成图片缩略图"""
        try:
            # 创建缩略图目录
            thumb_dir = Config.UPLOAD_FOLDER / 'thumbnails'
            thumb_dir.mkdir(exist_ok=True)
            
            thumb_path = thumb_dir / f"thumb_{filename}"
            
            # 打开并生成缩略图
            with Image.open(image_path) as img:
                # 保持宽高比
                img.thumbnail(size, Image.Resampling.LANCZOS)
                
                # 如果是PNG，保持透明度
                if img.mode in ('RGBA', 'LA'):
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'RGBA':
                        background.paste(img, mask=img.split()[-1])
                    else:
                        background.paste(img, mask=img)
                    img = background
                
                # 保存缩略图
                img.save(thumb_path, 'JPEG', quality=85)
            
            return thumb_path
            
        except Exception as e:
            self.logger.log_error(f"生成缩略图失败: {str(e)}", {
                'filename': filename
            })
            return image_path  # 返回原图作为后备
    
    def _find_file_by_name(self, filename: str) -> Optional[Path]:
        """根据文件名查找文件"""
        # 遍历上传目录查找文件
        for root, dirs, files in os.walk(Config.UPLOAD_FOLDER):
            for file in files:
                if file == filename:
                    return Path(root) / file
        
        return None
    
    def _get_file_info(self, file_path: Path) -> Dict:
        """获取文件信息"""
        stat = file_path.stat()
        
        return {
            'filename': file_path.name,
            'path': str(file_path.relative_to(Config.UPLOAD_FOLDER)),
            'size': stat.st_size,
            'size_human': self._humanize_size(stat.st_size),
            'created_time': datetime.fromtimestamp(stat.st_ctime).isoformat(),
            'modified_time': datetime.fromtimestamp(stat.st_mtime).isoformat()
        }
    
    def _humanize_size(self, size_bytes: int) -> str:
        """将字节大小转换为易读格式"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} PB"
    
    def _is_conversion_supported(self, source_format: str, target_format: str) -> bool:
        """检查是否支持格式转换"""
        # 定义支持的转换矩阵
        supported_conversions = {
            'doc': ['pdf', 'txt'],
            'docx': ['pdf', 'txt'],
            'pdf': ['txt'],
            'jpg': ['png', 'webp'],
            'png': ['jpg', 'webp']
        }
        
        return (source_format in supported_conversions and 
                target_format in supported_conversions[source_format])
    
    def _perform_conversion(self, source_path: Path, source_ext: str, 
                       target_format: str, user_id: int) -> Optional[Path]:
    """
    执行文件格式转换
    支持多种文档、图片、表格格式互转
    
    Args:
        source_path: 源文件路径
        source_ext: 源文件扩展名
        target_format: 目标格式
        user_id: 用户ID
    
    Returns:
        Path: 转换后的文件路径
    """
    try:
        # 图片格式转换
        if source_ext in ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif', 'tiff'] and \
           target_format in ['jpg', 'png', 'webp', 'bmp', 'gif']:
            return self._convert_image_format(source_path, source_ext, target_format)
        
        # PDF相关转换
        elif source_ext == 'pdf':
            if target_format in ['docx', 'txt', 'html', 'jpg']:
                return self._convert_from_pdf(source_path, target_format)
        
        # Word文档转换
        elif source_ext in ['doc', 'docx']:
            if target_format in ['pdf', 'txt', 'html']:
                return self._convert_from_word(source_path, source_ext, target_format)
        
        # Excel表格转换
        elif source_ext in ['xls', 'xlsx']:
            if target_format in ['pdf', 'csv', 'html']:
                return self._convert_from_excel(source_path, source_ext, target_format)
        
        # PowerPoint转换
        elif source_ext in ['ppt', 'pptx']:
            if target_format in ['pdf', 'jpg', 'html']:
                return self._convert_from_powerpoint(source_path, source_ext, target_format)
        
        # 纯文本转换
        elif source_ext == 'txt':
            if target_format in ['pdf', 'html', 'docx']:
                return self._convert_from_text(source_path, target_format)
        
        # Markdown转换
        elif source_ext == 'md':
            if target_format in ['html', 'pdf', 'docx']:
                return self._convert_from_markdown(source_path, target_format)
        
        # HTML转换
        elif source_ext == 'html':
            if target_format in ['pdf', 'docx', 'txt']:
                return self._convert_from_html(source_path, target_format)
        
        else:
            self.logger.log_error(f"不支持的转换类型: {source_ext} -> {target_format}")
            return None
            
    except Exception as e:
        self.logger.log_error(f"文件转换失败: {str(e)}", {
            'source': source_path.name,
            'target': target_format
        })
        return None

# ==================== 具体的转换方法 ====================

def _convert_image_format(self, source_path: Path, source_ext: str, 
                         target_format: str) -> Optional[Path]:
    """图片格式转换"""
    try:
        with Image.open(source_path) as img:
            # 创建转换后文件路径
            target_name = f"{source_path.stem}_converted.{target_format}"
            target_path = source_path.parent / target_name
            
            # 处理RGBA模式的图片
            if img.mode in ('RGBA', 'LA', 'P'):
                if img.mode == 'P':
                    img = img.convert('RGBA')
                
                # 如果目标格式不支持透明度，添加白色背景
                if target_format in ['jpg', 'bmp']:
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'RGBA':
                        background.paste(img, mask=img.split()[-1])
                    else:
                        background.paste(img, mask=img)
                    img = background
                else:
                    # 保持透明度
                    img = img.convert('RGBA')
            
            # 保存为不同格式
            save_params = {
                'quality': 95,
                'optimize': True
            }
            
            if target_format == 'jpg':
                img.convert('RGB').save(target_path, 'JPEG', **save_params)
            elif target_format == 'png':
                img.save(target_path, 'PNG', **save_params)
            elif target_format == 'webp':
                img.save(target_path, 'WEBP', **save_params)
            elif target_format == 'bmp':
                img.convert('RGB').save(target_path, 'BMP')
            elif target_format == 'gif':
                # 如果是动图，保持动画
                if hasattr(img, 'is_animated') and img.is_animated:
                    img.save(target_path, 'GIF', 
                           save_all=True, 
                           append_images=[img],
                           duration=img.info.get('duration', 100),
                           loop=img.info.get('loop', 0))
                else:
                    img.save(target_path, 'GIF')
            
            return target_path
            
    except Exception as e:
        self.logger.log_error(f"图片格式转换失败: {str(e)}")
        return None

def _convert_from_pdf(self, source_path: Path, target_format: str) -> Optional[Path]:
    """PDF文件转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        if target_format == 'docx':
            # PDF转Word
            try:
                from pdf2docx import Converter
                
                cv = Converter(str(source_path))
                cv.convert(str(target_path))
                cv.close()
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装pdf2docx库")
                return None
        
        elif target_format == 'txt':
            # PDF转文本
            try:
                import PyPDF2
                
                with open(source_path, 'rb') as pdf_file:
                    pdf_reader = PyPDF2.PdfReader(pdf_file)
                    text_content = []
                    
                    for page_num in range(len(pdf_reader.pages)):
                        page = pdf_reader.pages[page_num]
                        text = page.extract_text()
                        text_content.append(text)
                    
                    with open(target_path, 'w', encoding='utf-8') as txt_file:
                        txt_file.write('\n'.join(text_content))
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装PyPDF2库")
                return None
        
        elif target_format == 'html':
            # PDF转HTML
            try:
                from pdfminer.high_level import extract_text_to_fp
                from pdfminer.layout import LAParams
                from io import StringIO
                
                output_string = StringIO()
                with open(source_path, 'rb') as pdf_file:
                    extract_text_to_fp(pdf_file, output_string, 
                                     laparams=LAParams(),
                                     output_type='html',
                                     codec='utf-8')
                
                html_content = output_string.getvalue()
                with open(target_path, 'w', encoding='utf-8') as html_file:
                    html_file.write(html_content)
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装pdfminer.six库")
                return None
        
        elif target_format == 'jpg':
            # PDF转图片（第一页）
            try:
                from pdf2image import convert_from_path
                
                images = convert_from_path(str(source_path), 
                                         first_page=1, 
                                         last_page=1,
                                         dpi=200)
                if images:
                    images[0].save(target_path, 'JPEG', quality=95)
                    return target_path
                return None
            except ImportError:
                self.logger.log_error("未安装pdf2image库")
                return None
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"PDF转换失败: {str(e)}")
        return None

def _convert_from_word(self, source_path: Path, source_ext: str, 
                      target_format: str) -> Optional[Path]:
    """Word文档转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        if target_format == 'pdf':
            # Word转PDF
            try:
                if source_ext == 'doc':
                    # 处理旧版.doc格式
                    try:
                        import win32com.client
                        import pythoncom
                        
                        pythoncom.CoInitialize()
                        word = win32com.client.Dispatch("Word.Application")
                        word.Visible = False
                        
                        doc = word.Documents.Open(str(source_path))
                        doc.SaveAs(str(target_path), FileFormat=17)  # PDF格式
                        doc.Close()
                        word.Quit()
                        
                        return target_path
                    except ImportError:
                        self.logger.log_error("Windows环境下需要安装pywin32")
                        return None
                else:
                    # 新版.docx转PDF
                    try:
                        from docx2pdf import convert
                        
                        convert(str(source_path), str(target_path))
                        return target_path
                    except ImportError:
                        self.logger.log_error("未安装docx2pdf库")
                        return None
                        
            except Exception as e:
                self.logger.log_error(f"Word转PDF失败: {str(e)}")
                return None
        
        elif target_format == 'txt':
            # Word转文本
            try:
                from docx import Document
                
                if source_ext == 'docx':
                    doc = Document(str(source_path))
                    text_content = []
                    
                    for paragraph in doc.paragraphs:
                        text_content.append(paragraph.text)
                    
                    with open(target_path, 'w', encoding='utf-8') as txt_file:
                        txt_file.write('\n'.join(text_content))
                else:
                    # .doc格式需要特殊处理
                    self.logger.log_error("暂不支持.doc转txt")
                    return None
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装python-docx库")
                return None
        
        elif target_format == 'html':
            # Word转HTML
            try:
                from htmldocx import HtmlToDocx
                from docx import Document
                
                if source_ext == 'docx':
                    doc = Document(str(source_path))
                    html_parser = HtmlToDocx()
                    html_content = html_parser.parse_document(doc)
                    
                    with open(target_path, 'w', encoding='utf-8') as html_file:
                        html_file.write(html_content)
                else:
                    self.logger.log_error("暂不支持.doc转html")
                    return None
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装htmldocx库")
                return None
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"Word文档转换失败: {str(e)}")
        return None

def _convert_from_excel(self, source_path: Path, source_ext: str, 
                       target_format: str) -> Optional[Path]:
    """Excel表格转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        if target_format == 'pdf':
            # Excel转PDF
            try:
                import pandas as pd
                from reportlab.lib.pagesizes import letter
                from reportlab.pdfgen import canvas
                from reportlab.lib.utils import ImageReader
                import io
                
                # 读取Excel文件
                df = pd.read_excel(source_path)
                
                # 创建PDF
                c = canvas.Canvas(str(target_path), pagesize=letter)
                width, height = letter
                
                # 设置字体和大小
                c.setFont("Helvetica", 10)
                
                # 写入数据
                y_position = height - 50
                for index, row in df.iterrows():
                    if y_position < 50:
                        c.showPage()
                        c.setFont("Helvetica", 10)
                        y_position = height - 50
                    
                    line = " | ".join([str(cell) for cell in row.values])
                    c.drawString(50, y_position, line[:100])  # 限制行长
                    y_position -= 15
                
                c.save()
                return target_path
                
            except ImportError:
                self.logger.log_error("未安装pandas或reportlab库")
                return None
        
        elif target_format == 'csv':
            # Excel转CSV
            try:
                import pandas as pd
                
                df = pd.read_excel(source_path)
                df.to_csv(target_path, index=False, encoding='utf-8')
                return target_path
            except ImportError:
                self.logger.log_error("未安装pandas库")
                return None
        
        elif target_format == 'html':
            # Excel转HTML
            try:
                import pandas as pd
                
                df = pd.read_excel(source_path)
                html_content = df.to_html(index=False, classes='table table-striped')
                
                # 添加基本样式
                styled_html = f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <style>
                        table {{ border-collapse: collapse; width: 100%; }}
                        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                        th {{ background-color: #f2f2f2; }}
                        tr:nth-child(even) {{ background-color: #f9f9f9; }}
                    </style>
                </head>
                <body>
                    {html_content}
                </body>
                </html>
                """
                
                with open(target_path, 'w', encoding='utf-8') as html_file:
                    html_file.write(styled_html)
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装pandas库")
                return None
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"Excel转换失败: {str(e)}")
        return None

def _convert_from_powerpoint(self, source_path: Path, source_ext: str, 
                           target_format: str) -> Optional[Path]:
    """PowerPoint转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        if target_format == 'pdf':
            # PPT转PDF（需要Microsoft PowerPoint或LibreOffice）
            try:
                # 方法1: 使用comtypes（Windows + Microsoft Office）
                try:
                    import comtypes.client
                    
                    powerpoint = comtypes.client.CreateObject("PowerPoint.Application")
                    powerpoint.Visible = False
                    
                    presentation = powerpoint.Presentations.Open(str(source_path))
                    presentation.SaveAs(str(target_path), 32)  # PDF格式
                    presentation.Close()
                    powerpoint.Quit()
                    
                    return target_path
                except ImportError:
                    pass
                
                # 方法2: 使用python-pptx和reportlab（仅限基本内容）
                try:
                    from pptx import Presentation
                    from reportlab.lib.pagesizes import letter
                    from reportlab.pdfgen import canvas
                    
                    prs = Presentation(str(source_path))
                    c = canvas.Canvas(str(target_path), pagesize=letter)
                    
                    for slide_num, slide in enumerate(prs.slides):
                        if slide_num > 0:
                            c.showPage()
                        
                        c.setFont("Helvetica", 12)
                        y_position = 700
                        
                        for shape in slide.shapes:
                            if hasattr(shape, "text"):
                                c.drawString(50, y_position, shape.text[:100])
                                y_position -= 20
                    
                    c.save()
                    return target_path
                except ImportError:
                    self.logger.log_error("未安装python-pptx库")
                    return None
                    
            except Exception as e:
                self.logger.log_error(f"PPT转PDF失败: {str(e)}")
                return None
        
        elif target_format == 'jpg':
            # PPT转图片（第一张幻灯片）
            try:
                from pptx import Presentation
                from PIL import Image as PILImage
                import io
                
                prs = Presentation(str(source_path))
                if prs.slides:
                    # 获取第一张幻灯片的缩略图（如果有）
                    # 临时方案：创建一个简单的占位图片
                    img = PILImage.new('RGB', (800, 600), color='lightblue')
                    img.save(target_path, 'JPEG', quality=95)
                    
                    return target_path
                return None
            except ImportError:
                self.logger.log_error("未安装python-pptx库")
                return None
        
        elif target_format == 'html':
            # PPT转HTML（简化版）
            try:
                from pptx import Presentation
                
                prs = Presentation(str(source_path))
                
                html_content = ["<!DOCTYPE html>", "<html>", "<head>",
                               "<meta charset='utf-8'>",
                               "<title>Presentation</title>",
                               "<style>",
                               "body { font-family: Arial, sans-serif; }",
                               ".slide { margin: 20px; padding: 20px; border: 1px solid #ddd; }",
                               "</style>",
                               "</head>", "<body>"]
                
                for slide_num, slide in enumerate(prs.slides):
                    html_content.append(f"<div class='slide'>")
                    html_content.append(f"<h2>Slide {slide_num + 1}</h2>")
                    
                    for shape in slide.shapes:
                        if hasattr(shape, "text") and shape.text.strip():
                            html_content.append(f"<p>{shape.text}</p>")
                    
                    html_content.append("</div>")
                
                html_content.extend(["</body>", "</html>"])
                
                with open(target_path, 'w', encoding='utf-8') as html_file:
                    html_file.write('\n'.join(html_content))
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装python-pptx库")
                return None
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"PowerPoint转换失败: {str(e)}")
        return None

def _convert_from_text(self, source_path: Path, target_format: str) -> Optional[Path]:
    """纯文本转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        with open(source_path, 'r', encoding='utf-8') as f:
            text_content = f.read()
        
        if target_format == 'pdf':
            # 文本转PDF
            try:
                from reportlab.lib.pagesizes import letter
                from reportlab.pdfgen import canvas
                from reportlab.lib.styles import getSampleStyleSheet
                from reportlab.platypus import SimpleDocTemplate, Paragraph
                from reportlab.lib.units import inch
                
                doc = SimpleDocTemplate(str(target_path), pagesize=letter,
                                      rightMargin=72, leftMargin=72,
                                      topMargin=72, bottomMargin=18)
                
                styles = getSampleStyleSheet()
                story = []
                
                # 分割文本为段落
                paragraphs = text_content.split('\n')
                for para in paragraphs:
                    if para.strip():
                        p = Paragraph(para, styles["Normal"])
                        story.append(p)
                
                doc.build(story)
                return target_path
            except ImportError:
                self.logger.log_error("未安装reportlab库")
                return None
        
        elif target_format == 'html':
            # 文本转HTML
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>{source_path.stem}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; line-height: 1.6; margin: 40px; }}
                    pre {{ white-space: pre-wrap; background-color: #f5f5f5; padding: 15px; }}
                </style>
            </head>
            <body>
                <pre>{text_content}</pre>
            </body>
            </html>
            """
            
            with open(target_path, 'w', encoding='utf-8') as html_file:
                html_file.write(html_content)
            
            return target_path
        
        elif target_format == 'docx':
            # 文本转Word
            try:
                from docx import Document
                
                doc = Document()
                paragraphs = text_content.split('\n')
                
                for para in paragraphs:
                    if para.strip():
                        doc.add_paragraph(para)
                
                doc.save(target_path)
                return target_path
            except ImportError:
                self.logger.log_error("未安装python-docx库")
                return None
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"文本转换失败: {str(e)}")
        return None

def _convert_from_markdown(self, source_path: Path, target_format: str) -> Optional[Path]:
    """Markdown转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        with open(source_path, 'r', encoding='utf-8') as f:
            markdown_content = f.read()
        
        if target_format == 'html':
            # Markdown转HTML
            try:
                import markdown
                
                html_content = markdown.markdown(markdown_content, 
                                               extensions=['extra', 'codehilite', 'tables'])
                
                # 添加完整HTML结构
                full_html = f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <title>{source_path.stem}</title>
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/github.min.css">
                    <style>
                        body {{ max-width: 800px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif; }}
                        code {{ background-color: #f5f5f5; padding: 2px 4px; }}
                        pre {{ background-color: #f5f5f5; padding: 10px; overflow: auto; }}
                        table {{ border-collapse: collapse; width: 100%; }}
                        th, td {{ border: 1px solid #ddd; padding: 8px; }}
                    </style>
                </head>
                <body>
                    {html_content}
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js"></script>
                    <script>hljs.highlightAll();</script>
                </body>
                </html>
                """
                
                with open(target_path, 'w', encoding='utf-8') as html_file:
                    html_file.write(full_html)
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装markdown库")
                return None
        
        elif target_format == 'pdf':
            # Markdown转PDF（通过HTML中转）
            try:
                import markdown
                from weasyprint import HTML
                
                html_content = markdown.markdown(markdown_content)
                HTML(string=html_content).write_pdf(str(target_path))
                return target_path
            except ImportError:
                self.logger.log_error("未安装weasyprint或markdown库")
                return None
        
        elif target_format == 'docx':
            # Markdown转Word
            try:
                from docx import Document
                import markdown
                
                html_content = markdown.markdown(markdown_content)
                
                # 简单的HTML到文本转换
                import re
                clean_text = re.sub('<[^<]+?>', '', html_content)
                clean_text = re.sub('\n+', '\n', clean_text).strip()
                
                doc = Document()
                doc.add_paragraph(clean_text)
                doc.save(target_path)
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装markdown或python-docx库")
                return None
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"Markdown转换失败: {str(e)}")
        return None

def _convert_from_html(self, source_path: Path, target_format: str) -> Optional[Path]:
    """HTML转换"""
    try:
        target_name = f"{source_path.stem}_converted.{target_format}"
        target_path = source_path.parent / target_name
        
        with open(source_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        if target_format == 'pdf':
            # HTML转PDF
            try:
                from weasyprint import HTML
                
                HTML(string=html_content).write_pdf(str(target_path))
                return target_path
            except ImportError:
                try:
                    from xhtml2pdf import pisa
                    
                    with open(target_path, "wb") as pdf_file:
                        pisa.CreatePDF(html_content, pdf_file)
                    
                    return target_path
                except ImportError:
                    self.logger.log_error("未安装weasyprint或xhtml2pdf库")
                    return None
        
        elif target_format == 'docx':
            # HTML转Word
            try:
                from htmldocx import HtmlToDocx
                from docx import Document
                
                doc = Document()
                parser = HtmlToDocx()
                parser.add_html_to_document(html_content, doc)
                doc.save(target_path)
                
                return target_path
            except ImportError:
                self.logger.log_error("未安装htmldocx库")
                return None
        
        elif target_format == 'txt':
            # HTML转文本
            try:
                from bs4 import BeautifulSoup
                
                soup = BeautifulSoup(html_content, 'html.parser')
                text_content = soup.get_text(separator='\n')
                
                # 清理多余空行
                lines = [line.strip() for line in text_content.split('\n') if line.strip()]
                clean_text = '\n'.join(lines)
                
                with open(target_path, 'w', encoding='utf-8') as txt_file:
                    txt_file.write(clean_text)
                
                return target_path
            except ImportError:
                # 简单正则方法
                import re
                
                clean_text = re.sub('<[^<]+?>', '', html_content)
                clean_text = re.sub('\n+', '\n', clean_text).strip()
                
                with open(target_path, 'w', encoding='utf-8') as txt_file:
                    txt_file.write(clean_text)
                
                return target_path
        
        else:
            return None
            
    except Exception as e:
        self.logger.log_error(f"HTML转换失败: {str(e)}")
        return None
    
    def _compress_image_file(self, image_path: Path, quality: int, 
                           user_id: int) -> Optional[Path]:
        """压缩图片文件"""
        try:
            with Image.open(image_path) as img:
                # 创建压缩后文件路径
                compressed_name = f"{image_path.stem}_compressed{image_path.suffix}"
                compressed_path = image_path.parent / compressed_name
                
                # 获取原始格式
                img_format = img.format or 'JPEG'
                
                # 压缩并保存
                if img_format == 'PNG':
                    # PNG压缩（使用优化）
                    img.save(compressed_path, 'PNG', optimize=True)
                else:
                    # JPEG或其他格式
                    img.save(compressed_path, img_format, quality=quality, optimize=True)
                
                return compressed_path
                
        except Exception as e:
            self.logger.log_error(f"图片压缩失败: {str(e)}")
            return None
    
    def _get_thumbnail_path(self, filename: str) -> Path:
        """获取缩略图路径"""
        thumb_dir = Config.UPLOAD_FOLDER / 'thumbnails'
        return thumb_dir / f"thumb_{filename}"
    
    def _update_file_record(self, filename: str, updates: Dict):
        """更新文件记录"""
        try:
            from models.file import FileRecord
            record = FileRecord.query.filter_by(saved_name=filename).first()
            if record:
                for key, value in updates.items():
                    setattr(record, key, value)
                db.session.commit()
        except Exception as e:
            self.logger.log_error(f"更新文件记录失败: {str(e)}")
    
    def _delete_file_record(self, filename: str):
        """删除文件记录"""
        try:
            from models.file import FileRecord
            record = FileRecord.query.filter_by(saved_name=filename).first()
            if record:
                db.session.delete(record)
                db.session.commit()
        except Exception as e:
            self.logger.log_error(f"删除文件记录失败: {str(e)}")
    
    def _get_original_filename(self, saved_filename: str) -> Optional[str]:
        """根据保存的文件名获取原始文件名"""
        try:
            from models.file import FileRecord
            record = FileRecord.query.filter_by(saved_name=saved_filename).first()
            return record.original_name if record else None
        except Exception as e:
            self.logger.log_error(f"获取原始文件名失败: {str(e)}")
            return None
    
    def _update_download_stats(self, filename: str, user_id: int):
        """更新下载统计"""
        try:
            from models.file import FileRecord
            record = FileRecord.query.filter_by(saved_name=filename).first()
            if record:
                record.download_count = (record.download_count or 0) + 1
                record.last_downloaded_at = datetime.utcnow()
                record.last_downloaded_by = user_id
                db.session.commit()
        except Exception as e:
            self.logger.log_error(f"更新下载统计失败: {str(e)}")
    
    def cleanup_temp_files(self, older_than_hours: int = 24) -> Dict:
        """
        清理临时文件
        
        Args:
            older_than_hours: 清理多少小时前的文件
        
        Returns:
            Dict: 清理结果
        """
        try:
            temp_dir = Config.UPLOAD_FOLDER / 'temp'
            if not temp_dir.exists():
                return {'success': True, 'message': '临时目录不存在', 'deleted': 0}
            
            cutoff_time = datetime.now().timestamp() - (older_than_hours * 3600)
            deleted_files = []
            
            for file_path in temp_dir.rglob('*'):
                if file_path.is_file():
                    if file_path.stat().st_mtime < cutoff_time:
                        try:
                            file_path.unlink()
                            deleted_files.append(file_path.name)
                        except Exception as e:
                            self.logger.log_error(f"删除临时文件失败: {str(e)}", {
                                'file': file_path.name
                            })
            
            # 删除空目录
            for dir_path in temp_dir.rglob('*'):
                if dir_path.is_dir() and not any(dir_path.iterdir()):
                    try:
                        dir_path.rmdir()
                    except Exception:
                        pass
            
            self.logger.log_operation(
                user_id=0,  # 系统操作
                operation_type='cleanup_temp_files',
                target_type='system',
                target_id=None,
                details={
                    'deleted_count': len(deleted_files),
                    'older_than_hours': older_than_hours
                }
            )
            
            return {
                'success': True,
                'deleted_count': len(deleted_files),
                'deleted_files': deleted_files,
                'message': f'清理了 {len(deleted_files)} 个临时文件'
            }
            
        except Exception as e:
            self.logger.log_error(f"清理临时文件失败: {str(e)}")
            return {'success': False, 'error': str(e)}
from app import db
from models import Document, DocumentVersion
from utils.log_utils import SystemLogger
from datetime import datetime

class VersionService:
    """版本管理服务"""
    
    def __init__(self):
        self.logger = SystemLogger()
    
    def create_version(self, document_id, content, change_log, created_by):
        """
        创建文档新版本
        
        Args:
            document_id: 文档ID
            content: 文档内容
            change_log: 变更说明
            created_by: 创建者ID
        
        Returns:
            DocumentVersion: 版本对象
        """
        try:
            document = Document.query.get(document_id)
            if not document:
                raise ValueError(f"文档 {document_id} 不存在")
            
            # 获取当前版本号
            latest_version = DocumentVersion.query.filter_by(
                document_id=document_id
            ).order_by(DocumentVersion.version_number.desc()).first()
            
            new_version = latest_version.version_number + 1 if latest_version else 1
            
            # 创建版本记录
            version = DocumentVersion(
                document_id=document_id,
                version_number=new_version,
                content=content,
                change_log=change_log or f"更新到版本 {new_version}",
                created_by=created_by
            )
            
            db.session.add(version)
            
            # 更新文档当前版本
            document.current_version = new_version
            document.content = content
            document.updated_at = datetime.utcnow()
            
            db.session.commit()
            
            self.logger.log_operation(
                user_id=created_by,
                operation_type='create_version',
                target_type='document',
                target_id=document_id,
                details={'version': new_version}
            )
            
            return version
            
        except Exception as e:
            db.session.rollback()
            self.logger.log_error(f"创建版本失败: {str(e)}")
            raise
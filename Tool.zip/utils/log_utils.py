# utils/log_utils.py
import logging
import json
from datetime import datetime
from pathlib import Path

class SystemLogger:
    """系统日志记录器"""
    
    def __init__(self, log_dir='logs'):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # 配置日志
        self._setup_logging()
    
    def _setup_logging(self):
        """配置日志系统"""
        # 创建不同级别的日志处理器
        log_file = self.log_dir / f"system_{datetime.now().strftime('%Y%m%d')}.log"
        
        # 配置根日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()  # 同时输出到控制台
            ]
        )
        
        self.logger = logging.getLogger('document_system')
    
    def log_operation(self, user_id, operation_type, target_type, target_id, details=None):
        """
        记录用户操作日志
        
        Args:
            user_id: 用户ID
            operation_type: 操作类型
            target_type: 目标类型
            target_id: 目标ID
            details: 操作详情
        """
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'user_id': user_id,
            'operation': operation_type,
            'target_type': target_type,
            'target_id': target_id,
            'details': details or {}
        }
        
        # 记录到文件
        log_file = self.log_dir / f"operation_{datetime.now().strftime('%Y%m%d')}.log"
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
        
        # 同时记录到系统日志
        self.logger.info(f"用户操作: {json.dumps(log_entry, ensure_ascii=False)}")
    
    def log_error(self, error_message, context=None):
        """
        记录错误日志
        
        Args:
            error_message: 错误信息
            context: 错误上下文
        """
        error_entry = {
            'timestamp': datetime.now().isoformat(),
            'level': 'ERROR',
            'message': error_message,
            'context': context or {}
        }
        
        self.logger.error(json.dumps(error_entry, ensure_ascii=False))
    
    def log_performance(self, endpoint, response_time, query_count=None):
        """
        记录性能日志
        
        Args:
            endpoint: API端点
            response_time: 响应时间(毫秒)
            query_count: 数据库查询次数
        """
        perf_entry = {
            'timestamp': datetime.now().isoformat(),
            'endpoint': endpoint,
            'response_time_ms': response_time,
            'query_count': query_count
        }
        
        # 记录慢查询（响应时间 > 500ms）
        if response_time > 500:
            self.logger.warning(f"慢查询: {json.dumps(perf_entry, ensure_ascii=False)}")
    
    def log_version(self, document_id, version_number, user_id, action, **kwargs):
        """
        记录版本操作日志
        
        Args:
            document_id: 文档ID
            version_number: 版本号
            user_id: 用户ID
            action: 操作类型
            **kwargs: 其他参数
        """
        version_log = {
            'timestamp': datetime.now().isoformat(),
            'document_id': document_id,
            'version': version_number,
            'user_id': user_id,
            'action': action,
            **kwargs
        }
        
        log_file = self.log_dir / f"version_{datetime.now().strftime('%Y%m%d')}.log"
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(version_log, ensure_ascii=False) + '\n')
"""
文件处理工具模块
包含文件上传、验证、处理等功能
"""

import os
import hashlib
import uuid
import mimetypes
from datetime import datetime
from pathlib import Path
from werkzeug.utils import secure_filename
from typing import Dict, List, Optional, Tuple
import magic

class FileProcessor:
    """文件处理器"""
    
    def __init__(self, upload_folder: str, max_size: int = 50 * 1024 * 1024):
        """
        初始化文件处理器
        
        Args:
            upload_folder: 上传目录
            max_size: 最大文件大小（字节）
        """
        self.upload_folder = Path(D:/Tool/src/static/uploads/)
        self.max_size = max_size
        self.allowed_extensions = {
            '文档': ['.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'],
            '图片': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'],
            '压缩包': ['.zip', '.rar', '.7z', '.tar', '.gz']
        }
        
        # 创建上传目录
        self.upload_folder.mkdir(parents=True, exist_ok=True)
    
    def is_allowed_file(self, filename: str) -> Tuple[bool, Optional[str]]:
        """
        检查文件是否允许上传
        
        Args:
            filename: 文件名
        
        Returns:
            Tuple[bool, Optional[str]]: (是否允许, 文件类型)
        """
        # 安全检查
        if not filename or '..' in filename or filename.startswith('/'):
            return False, None
        
        # 获取扩展名
        ext = Path(filename).suffix.lower()
        
        # 检查扩展名
        for file_type, extensions in self.allowed_extensions.items():
            if ext in extensions:
                return True, file_type
        
        return False, None
    
    def generate_unique_filename(self, original_filename: str) -> str:
        """
        生成唯一文件名
        
        Args:
            original_filename: 原始文件名
        
        Returns:
            str: 唯一文件名
        """
        # 安全处理文件名
        safe_name = secure_filename(original_filename)
        
        # 分离扩展名
        stem = Path(safe_name).stem
        ext = Path(safe_name).suffix
        
        # 生成唯一ID和时间戳
        unique_id = str(uuid.uuid4())[:8]
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # 构建新文件名
        return f"{timestamp}_{unique_id}_{stem}{ext}"
    
    def validate_file(self, file_stream, filename: str) -> Dict:
        """
        验证文件
        
        Args:
            file_stream: 文件流
            filename: 文件名
        
        Returns:
            Dict: 验证结果
        """
        # 检查文件扩展名
        is_allowed, file_type = self.is_allowed_file(filename)
        if not is_allowed:
            return {
                'valid': False,
                'error': '不支持的文件类型'
            }
        
        try:
            # 检查文件大小
            file_size = 0
            file_stream.seek(0, 2)  # 移动到文件末尾
            file_size = file_stream.tell()
            file_stream.seek(0)  # 移动回文件开头
            
            if file_size > self.max_size:
                return {
                    'valid': False,
                    'error': f'文件大小超过限制 ({file_size} > {self.max_size})'
                }
            
            # 检查MIME类型
            file_content = file_stream.read(2048)
            file_stream.seek(0)
            
            mime_type = magic.from_buffer(file_content, mime=True)
            
            # 验证MIME类型
            allowed_mimes = {
                'application/pdf': ['.pdf'],
                'application/msword': ['.doc'],
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
                'image/jpeg': ['.jpg', '.jpeg'],
                'image/png': ['.png'],
                'text/plain': ['.txt']
            }
            
            # 检查MIME类型是否与扩展名匹配
            ext = Path(filename).suffix.lower()
            if mime_type in allowed_mimes and ext not in allowed_mimes[mime_type]:
                return {
                    'valid': False,
                    'error': '文件内容与扩展名不匹配'
                }
            
            return {
                'valid': True,
                'file_type': file_type,
                'mime_type': mime_type,
                'size': file_size
            }
            
        except Exception as e:
            return {
                'valid': False,
                'error': f'文件验证失败: {str(e)}'
            }
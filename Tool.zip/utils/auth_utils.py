# utils/auth_utils.py
class RBACValidator:
    """基于角色的访问控制验证器"""
    
    def __init__(self, app):
        self.app = app
        self.role_hierarchy = {
            1: ['admin', 'edit', 'view', 'delete'],
            2: ['edit', 'view'],
            3: ['view']
        }
    
    def has_permission(self, user_role_level, required_permission):
        """
        检查用户角色是否拥有所需权限
        
        Args:
            user_role_level: 用户角色等级
            required_permission: 需要的权限类型
        
        Returns:
            bool: 是否拥有权限
        """
        if user_role_level not in self.role_hierarchy:
            return False
        
        allowed_permissions = self.role_hierarchy[user_role_level]
        return required_permission in allowed_permissions
    
    def check_document_permission(self, user_id, document_id, action):
        """
        检查用户对特定文档的权限
        
        Args:
            user_id: 用户ID
            document_id: 文档ID
            action: 操作类型 ('view', 'edit', 'delete')
        
        Returns:
            bool: 是否允许操作
        """
        # 1. 检查是否为文档所有者
        document = Document.query.get(document_id)
        if document and document.owner_id == user_id:
            return True
        
        # 2. 检查RBAC角色权限
        user = User.query.get(user_id)
        if user and self.has_permission(user.role.level, action):
            return True
        
        # 3. 检查特定文档权限
        permission = Permission.query.filter_by(
            user_id=user_id,
            document_id=document_id,
            permission_type=action
        ).first()
        
        if permission and (not permission.expires_at or 
                          permission.expires_at > datetime.now()):
            return True
        
        return False
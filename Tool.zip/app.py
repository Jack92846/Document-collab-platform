"""
文档协同管理平台 - 主应用入口
版本: 1.0.0
作者: [Jack]
"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from config import config

# 扩展初始化
db = SQLAlchemy()
migrate = Migrate()

def create_app(config_name='default'):
    """
    应用工厂函数
    
    Args:
        config_name: 配置名称 ('development', 'production', 'default')
    
    Returns:
        Flask: Flask应用实例
    """
    app = Flask(__name__)
    
    # 加载配置
    app.config.from_object(config[config_name])
    
    # 初始化扩展
    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app)
    
    # 注册蓝图
    from api.auth import auth_bp
    from api.document import document_bp
    from api.user import user_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(document_bp)
    app.register_blueprint(user_bp)
    
    # 注册中间件
    from middleware.auth_middleware import AuthMiddleware
    app.wsgi_app = AuthMiddleware(app.wsgi_app)
    
    # 创建数据库表（开发环境）
    if config_name == 'development':
        with app.app_context():
            db.create_all()
    
    # 添加请求钩子
    @app.before_request
    def before_request():
        """请求前处理"""
        pass
    
    @app.after_request
    def after_request(response):
        """请求后处理"""
        # 添加安全头部
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        return response
    
    # 健康检查端点
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'service': 'document-management'}
    
    return app

if __name__ == '__main__':
    app = create_app('development')
    app.run(host='0.0.0.0', port=5000, debug=True)